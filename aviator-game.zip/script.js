
console.log("Aviator Crash Game loaded...");
